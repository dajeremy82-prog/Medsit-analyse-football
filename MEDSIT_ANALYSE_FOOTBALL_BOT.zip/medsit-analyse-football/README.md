# MEDSIT ANALYSE FOOTBALL — bot Telegram débutant

## Ce que fait cette première version
- `/start` : affiche les instructions.
- `/aide` : affiche les instructions.
- `/test` : vérifie que le bot répond.
- `/analyse Équipe A;Équipe B;1.6;1.1` : calcule des probabilités 1X2, Over 1,5, Over 2,5 et BTTS à partir de deux xG saisis manuellement.

Les noms et xG de l'exemple sont fictifs. Le bot ne récupère pas automatiquement les statistiques, les absences ou les cotes 1xBet. Les résultats sont des estimations, jamais une garantie de gain.

## Mise en ligne gratuite (Render)
Les offres gratuites et leurs règles peuvent changer. Un service gratuit peut s'endormir ou être limité ; la disponibilité 24 h/24 n'est pas garantie.

1. Crée ton bot avec `@BotFather` sur Telegram en envoyant `/newbot`.
2. Garde le token secret. Ne le mets jamais dans le code ou dans un dépôt public.
3. Sur GitHub, crée un nouveau dépôt nommé `medsit-analyse-football` et ajoute `bot.py`, `requirements.txt` et `Procfile`.
4. Sur Render, crée un compte et choisis **New + → Web Service**, puis connecte ton dépôt GitHub.
5. Paramètres du service :
   - Runtime : Python
   - Build command : `pip install -r requirements.txt`
   - Start command : `python bot.py`
6. Dans **Environment Variables** de Render, ajoute :
   - `TELEGRAM_BOT_TOKEN` = le token fourni par BotFather
   - `RENDER_EXTERNAL_URL` = l'URL publique Render complète, par exemple `https://nom-du-service.onrender.com` (sans slash final)
7. Déploie le service. Si tu modifies l'URL publique plus tard, mets à jour `RENDER_EXTERNAL_URL` et redéploie.
8. Ouvre ton bot sur Telegram et envoie `/start`, puis `/test`.

### Ajouter les fichiers depuis Android
Tu peux utiliser le site GitHub dans Chrome en mode bureau pour créer le dépôt et téléverser les fichiers. Render se connecte ensuite au dépôt.

### Exemple de commande
`/analyse Équipe A;Équipe B;1.6;1.1`

Les points-virgules séparent les 4 champs. Les nombres peuvent utiliser un point ou une virgule décimale.

## Sécurité
- Ne communique jamais le token du bot à quelqu'un.
- Si le token fuit, ouvre `@BotFather`, révoque-le/regénère-le avec `/revoke` ou les commandes de gestion du bot, puis remplace la variable sur Render.
- Ne demande pas aux utilisateurs de transmettre des mots de passe ou données bancaires.
