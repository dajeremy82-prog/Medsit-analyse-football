import os
import math
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
PUBLIC_URL = os.environ.get("RENDER_EXTERNAL_URL", "").strip().rstrip("/")
PORT = int(os.environ.get("PORT", "10000"))

def poisson(k: int, lam: float) -> float:
    return math.exp(-lam) * (lam ** k) / math.factorial(k)

def probabilities(xg_home: float, xg_away: float, max_goals: int = 10):
    home = draw = away = over15 = over25 = btts = 0.0
    for h in range(max_goals + 1):
        ph = poisson(h, xg_home)
        for a in range(max_goals + 1):
            p = ph * poisson(a, xg_away)
            if h > a:
                home += p
            elif h == a:
                draw += p
            else:
                away += p
            if h + a >= 2:
                over15 += p
            if h + a >= 3:
                over25 += p
            if h >= 1 and a >= 1:
                btts += p
    return {
        "1": home * 100,
        "X": draw * 100,
        "2": away * 100,
        "over15": over15 * 100,
        "over25": over25 * 100,
        "btts": btts * 100,
    }

def pct(value: float) -> str:
    return f"{value:.1f}%"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = (
        "⚽ MEDSIT ANALYSE FOOTBALL\n\n"
        "Je calcule une estimation statistique simple à partir des xG que tu saisis.\n"
        "Les résultats dépendent des données fournies : ce n'est pas une garantie de gain.\n\n"
        "Commande :\n"
        "/analyse Équipe domicile;Équipe extérieure;xG domicile;xG extérieur\n\n"
        "Exemple fictif :\n"
        "/analyse Équipe A;Équipe B;1.6;1.1\n\n"
        "Commandes disponibles : /aide"
    )
    await update.message.reply_text(message)

async def aide(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)

async def analyse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "Format attendu :\n/analyse Équipe domicile;Équipe extérieure;xG domicile;xG extérieur\n"
            "Exemple fictif :\n/analyse Équipe A;Équipe B;1.6;1.1"
        )
        return

    raw = " ".join(context.args)
    parts = [p.strip() for p in raw.split(";")]
    if len(parts) != 4:
        await update.message.reply_text(
            "Il faut exactement 4 éléments séparés par des points-virgules (;).\n"
            "Exemple fictif : /analyse Équipe A;Équipe B;1.6;1.1"
        )
        return

    home_name, away_name = parts[0], parts[1]
    try:
        xg_home = float(parts[2].replace(",", "."))
        xg_away = float(parts[3].replace(",", "."))
    except ValueError:
        await update.message.reply_text("Les deux xG doivent être des nombres, par exemple 1.6 et 1.1.")
        return

    if not home_name or not away_name or not (0 <= xg_home <= 6 and 0 <= xg_away <= 6):
        await update.message.reply_text("Vérifie les noms et saisis des xG entre 0 et 6.")
        return

    p = probabilities(xg_home, xg_away)
    outcomes = [("1", p["1"]), ("Nul", p["X"]), ("2", p["2"])]
    best = max(outcomes, key=lambda item: item[1])
    best_label = {"1": f"Victoire {home_name}", "Nul": "Match nul", "2": f"Victoire {away_name}"}[best[0]]

    text = (
        f"⚽ MEDSIT ANALYSE FOOTBALL\n"
        f"{home_name} – {away_name}\n\n"
        f"📊 Entrées manuelles (xG estimés)\n"
        f"• {home_name} : {xg_home:.2f}\n"
        f"• {away_name} : {xg_away:.2f}\n\n"
        f"🎯 Probabilités estimées 1X2\n"
        f"• 1 — {home_name} : {pct(p['1'])}\n"
        f"• X — Nul : {pct(p['X'])}\n"
        f"• 2 — {away_name} : {pct(p['2'])}\n\n"
        f"🥅 Marchés de buts\n"
        f"• Plus de 1,5 but : {pct(p['over15'])}\n"
        f"• Plus de 2,5 buts : {pct(p['over25'])}\n"
        f"• BTTS — les deux marquent : {pct(p['btts'])}\n\n"
        f"🔎 Issue la plus probable selon ce modèle : {best_label} ({pct(best[1])}).\n\n"
        f"⚠️ Modèle simplifié de Poisson basé uniquement sur les xG saisis. "
        f"Il ne vérifie pas les absences, la forme, les compositions ni les cotes 1xBet. "
        f"Ne considère pas ce résultat comme une garantie ou un conseil financier."
    )
    await update.message.reply_text(text)

async def health(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("MEDSIT ANALYSE FOOTBALL est en ligne ✅")

def main():
    if not TOKEN:
        raise RuntimeError("Variable TELEGRAM_BOT_TOKEN manquante.")
    if not PUBLIC_URL:
        raise RuntimeError("Variable RENDER_EXTERNAL_URL manquante (URL publique Render).")

    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("aide", aide))
    app.add_handler(CommandHandler("help", aide))
    app.add_handler(CommandHandler("analyse", analyse))
    app.add_handler(CommandHandler("test", health))

    app.run_webhook(
        listen="0.0.0.0",
        port=PORT,
        url_path=TOKEN,
        webhook_url=f"{PUBLIC_URL}/{TOKEN}",
        drop_pending_updates=True,
    )

if __name__ == "__main__":
    main()
